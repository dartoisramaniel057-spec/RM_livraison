# RM Livraison
Sit entènèt RM Livraison.

## Louvri sit la
Double-clique sou `index.html` pou teste li sou telefòn/òdinatè.

## Mete l sou entènèt
Pibliye `index.html` sou GitHub Pages oswa yon lòt hosting estatik.
